Thank you for downloading Dive Into Greasemonkey, copyright 2005
by Mark Pilgrim.  I hope you enjoy it.  Please send comments,
corrections, and suggestions to <mark@diveintomark.org>.

This book is Free Software, licensed under the GNU General Public
License.  A copy of the license is included as an appendix.

Table of contents:    $DIRECTORY/toc/index.html
Example user scripts: $DIRECTORY/examples/
Latest version:       http://diveintogreasemonkey.org/

Cheers,
-Mark
